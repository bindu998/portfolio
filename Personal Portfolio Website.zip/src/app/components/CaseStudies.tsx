import { motion } from 'motion/react';
import { TrendingUp, Users, DollarSign, Heart } from 'lucide-react';

export function CaseStudies() {
  const caseStudies = [
    {
      client: 'Premium Fashion Brand',
      industry: 'E-commerce',
      challenge: 'Low online sales and minimal social media presence',
      strategy: [
        'Developed comprehensive social media content calendar',
        'Launched targeted Meta Ads campaigns for key demographics',
        'Created engaging Reels and Stories for brand awareness',
        'Implemented influencer collaboration strategy',
      ],
      execution: [
        'Daily posting schedule with high-quality visuals',
        'A/B tested ad creatives and audiences',
        'Weekly analytics review and optimization',
        'Quarterly campaign adjustments based on performance',
      ],
      results: [
        { icon: DollarSign, metric: '8.5x ROAS', label: 'Return on Ad Spend' },
        { icon: TrendingUp, metric: '245%', label: 'Sales Increase' },
        { icon: Users, metric: '150K+', label: 'New Followers' },
        { icon: Heart, metric: '12%', label: 'Engagement Rate' },
      ],
      gradient: 'from-purple-600 to-pink-600',
    },
    {
      client: 'Local Restaurant Chain',
      industry: 'Food & Beverage',
      challenge: 'Need to increase foot traffic and online orders post-pandemic',
      strategy: [
        'Created mouthwatering food photography and videography',
        'Geo-targeted Facebook and Instagram ads',
        'Built engaging community through user-generated content',
        'Developed seasonal promotional campaigns',
      ],
      execution: [
        'Professional food photography shoots monthly',
        'Daily Stories featuring menu items and behind-the-scenes',
        'Strategic ad placements during peak ordering times',
        'Collaboration with local food bloggers',
      ],
      results: [
        { icon: Users, metric: '3,500+', label: 'New Leads' },
        { icon: TrendingUp, metric: '180%', label: 'Online Orders Up' },
        { icon: DollarSign, metric: '6.2x ROAS', label: 'Ad Performance' },
        { icon: Heart, metric: '85%', label: 'Customer Retention' },
      ],
      gradient: 'from-blue-600 to-cyan-600',
    },
    {
      client: 'Tech SaaS Startup',
      industry: 'B2B Technology',
      challenge: 'Generate qualified leads for enterprise software solution',
      strategy: [
        'Developed thought leadership content strategy',
        'Created educational video series on industry trends',
        'Implemented LinkedIn and Facebook lead gen campaigns',
        'Built comprehensive retargeting funnel',
      ],
      execution: [
        'Weekly blog posts and infographics',
        'Bi-weekly webinars and live Q&A sessions',
        'Targeted campaigns to decision-makers',
        'Multi-touch attribution tracking',
      ],
      results: [
        { icon: Users, metric: '850+', label: 'Qualified Leads' },
        { icon: DollarSign, metric: '45%', label: 'Conversion Rate' },
        { icon: TrendingUp, metric: '320%', label: 'Pipeline Growth' },
        { icon: Heart, metric: '4.8x', label: 'Lead Quality Score' },
      ],
      gradient: 'from-indigo-600 to-purple-600',
    },
  ];

  return (
    <section id="case-studies" className="py-20 sm:py-32 bg-gradient-to-b from-gray-50 to-white dark:from-gray-800 dark:to-gray-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl sm:text-5xl font-bold mb-4 bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent">
            Case Studies
          </h2>
          <div className="w-20 h-1 bg-gradient-to-r from-purple-600 to-blue-600 mx-auto rounded-full mb-6" />
          <p className="text-gray-600 dark:text-gray-400 max-w-2xl mx-auto text-lg">
            Real results from real campaigns
          </p>
        </motion.div>

        <div className="space-y-12">
          {caseStudies.map((study, index) => (
            <motion.div
              key={study.client}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.2 }}
              className="relative"
            >
              <div className="bg-white dark:bg-gray-800 rounded-3xl shadow-xl overflow-hidden border border-gray-100 dark:border-gray-700">
                {/* Header */}
                <div className={`bg-gradient-to-r ${study.gradient} p-8 sm:p-10 text-white`}>
                  <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
                    <div>
                      <h3 className="text-2xl sm:text-3xl font-bold mb-2">{study.client}</h3>
                      <p className="text-white/80">{study.industry}</p>
                    </div>
                    <div className="inline-block px-4 py-2 bg-white/20 backdrop-blur-md rounded-full text-sm font-medium">
                      Success Story
                    </div>
                  </div>
                </div>

                {/* Content */}
                <div className="p-8 sm:p-10 space-y-8">
                  {/* Challenge */}
                  <div>
                    <h4 className="text-xl font-bold text-gray-900 dark:text-white mb-3 flex items-center gap-2">
                      <div className="w-2 h-2 bg-gradient-to-r from-purple-600 to-blue-600 rounded-full" />
                      Challenge
                    </h4>
                    <p className="text-gray-600 dark:text-gray-400">{study.challenge}</p>
                  </div>

                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                    {/* Strategy */}
                    <div>
                      <h4 className="text-xl font-bold text-gray-900 dark:text-white mb-3 flex items-center gap-2">
                        <div className="w-2 h-2 bg-gradient-to-r from-purple-600 to-blue-600 rounded-full" />
                        Strategy
                      </h4>
                      <ul className="space-y-2">
                        {study.strategy.map((item, i) => (
                          <li key={i} className="flex items-start gap-2 text-gray-600 dark:text-gray-400">
                            <span className="text-purple-600 mt-1">•</span>
                            <span>{item}</span>
                          </li>
                        ))}
                      </ul>
                    </div>

                    {/* Execution */}
                    <div>
                      <h4 className="text-xl font-bold text-gray-900 dark:text-white mb-3 flex items-center gap-2">
                        <div className="w-2 h-2 bg-gradient-to-r from-purple-600 to-blue-600 rounded-full" />
                        Execution
                      </h4>
                      <ul className="space-y-2">
                        {study.execution.map((item, i) => (
                          <li key={i} className="flex items-start gap-2 text-gray-600 dark:text-gray-400">
                            <span className="text-blue-600 mt-1">•</span>
                            <span>{item}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>

                  {/* Results */}
                  <div>
                    <h4 className="text-xl font-bold text-gray-900 dark:text-white mb-6 flex items-center gap-2">
                      <div className="w-2 h-2 bg-gradient-to-r from-purple-600 to-blue-600 rounded-full" />
                      Results
                    </h4>
                    <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                      {study.results.map((result, i) => (
                        <motion.div
                          key={i}
                          whileHover={{ scale: 1.05, y: -5 }}
                          className="bg-gradient-to-br from-purple-50 to-blue-50 dark:from-purple-900/20 dark:to-blue-900/20 rounded-2xl p-6 text-center border border-purple-100 dark:border-purple-800/30"
                        >
                          <div className={`w-12 h-12 bg-gradient-to-r ${study.gradient} rounded-xl flex items-center justify-center mx-auto mb-3`}>
                            <result.icon className="text-white" size={20} />
                          </div>
                          <div className="text-2xl sm:text-3xl font-bold bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent mb-1">
                            {result.metric}
                          </div>
                          <div className="text-xs sm:text-sm text-gray-600 dark:text-gray-400">
                            {result.label}
                          </div>
                        </motion.div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
