import { motion } from 'motion/react';
import { Target, Award, Users, TrendingUp } from 'lucide-react';

export function About() {
  const stats = [
    { icon: Award, number: '3.5+', label: 'Years Experience' },
    { icon: Target, number: '100+', label: 'Campaigns Managed' },
    { icon: Users, number: '50+', label: 'Brands Worked With' },
    { icon: TrendingUp, number: 'ROI', label: 'Focused Strategies' },
  ];

  const expertise = [
    'Social Media Strategy',
    'Meta Ads Campaign Management',
    'Graphic Designing',
    'Video Editing & Reels Creation',
    'Brand Identity Development',
  ];

  return (
    <section id="about" className="py-20 sm:py-32 bg-white dark:bg-gray-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl sm:text-5xl font-bold mb-4 bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent">
            About Me
          </h2>
          <div className="w-20 h-1 bg-gradient-to-r from-purple-600 to-blue-600 mx-auto rounded-full" />
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          {/* Left - Bio */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="space-y-6"
          >
            <div className="prose prose-lg dark:prose-invert">
              <p className="text-gray-700 dark:text-gray-300">
                Hi, I'm <span className="font-bold text-purple-600">Bindu</span>, a passionate Social Media Manager with over 3.5 years of experience in transforming brands through strategic digital marketing and creative storytelling.
              </p>
              <p className="text-gray-700 dark:text-gray-300">
                I specialize in creating data-driven campaigns that don't just look good, but deliver measurable results. From conceptualizing viral content to managing high-ROI ad campaigns, I bring a perfect blend of creativity and analytics to every project.
              </p>
              <p className="text-gray-700 dark:text-gray-300">
                My mission is simple: to help brands build authentic connections with their audience and turn followers into loyal customers.
              </p>
            </div>

            {/* Expertise List */}
            <div className="pt-4">
              <h3 className="font-semibold text-xl mb-4 text-gray-900 dark:text-white">Core Expertise</h3>
              <div className="space-y-3">
                {expertise.map((skill, index) => (
                  <motion.div
                    key={skill}
                    initial={{ opacity: 0, x: -20 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    viewport={{ once: true }}
                    transition={{ delay: index * 0.1 }}
                    className="flex items-center gap-3"
                  >
                    <div className="w-2 h-2 bg-gradient-to-r from-purple-600 to-blue-600 rounded-full" />
                    <span className="text-gray-700 dark:text-gray-300">{skill}</span>
                  </motion.div>
                ))}
              </div>
            </div>
          </motion.div>

          {/* Right - Stats */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="grid grid-cols-2 gap-6"
          >
            {stats.map((stat, index) => (
              <motion.div
                key={stat.label}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                whileHover={{ scale: 1.05, y: -5 }}
                className="relative group"
              >
                <div className="bg-gradient-to-br from-purple-50 to-blue-50 dark:from-purple-900/20 dark:to-blue-900/20 rounded-2xl p-6 sm:p-8 border border-purple-100 dark:border-purple-800/30 shadow-lg hover:shadow-xl transition-all">
                  {/* Icon */}
                  <div className="w-12 h-12 sm:w-14 sm:h-14 bg-gradient-to-r from-purple-600 to-blue-600 rounded-2xl flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                    <stat.icon className="text-white" size={24} />
                  </div>
                  
                  {/* Number */}
                  <div className="text-3xl sm:text-4xl font-bold bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent mb-2">
                    {stat.number}
                  </div>
                  
                  {/* Label */}
                  <div className="text-gray-600 dark:text-gray-400 text-sm sm:text-base">
                    {stat.label}
                  </div>
                </div>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </div>
    </section>
  );
}
