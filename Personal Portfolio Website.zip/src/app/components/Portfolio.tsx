import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ExternalLink } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';

export function Portfolio() {
  const [activeFilter, setActiveFilter] = useState('All');

  const filters = ['All', 'Ads', 'Branding', 'Social Media', 'Video'];

  const projects = [
    {
      id: 1,
      title: 'Meta Ads Campaign - E-commerce Brand',
      category: 'Ads',
      image: 'https://images.unsplash.com/photo-1620313926202-159eb90ec94a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkaWdpdGFsJTIwbWFya2V0aW5nJTIwc29jaWFsJTIwbWVkaWElMjB3b3Jrc3BhY2V8ZW58MXx8fHwxNzcxMjUwNDA0fDA&ixlib=rb-4.1.0&q=80&w=1080',
      description: 'High-converting Meta Ads campaign with 5x ROAS',
    },
    {
      id: 2,
      title: 'Instagram Feed Design',
      category: 'Social Media',
      image: 'https://images.unsplash.com/photo-1643239120053-f2560e990141?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxpbnN0YWdyYW0lMjBmZWVkJTIwcGhvbmUlMjBtb2NrdXB8ZW58MXx8fHwxNzcxMjUwNDA1fDA&ixlib=rb-4.1.0&q=80&w=1080',
      description: 'Complete Instagram aesthetic overhaul for lifestyle brand',
    },
    {
      id: 3,
      title: 'Brand Identity Package',
      category: 'Branding',
      image: 'https://images.unsplash.com/photo-1770048792381-55d47c183faa?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxicmFuZGluZyUyMGRlc2lnbiUyMG1vY2t1cCUyMGxhcHRvcHxlbnwxfHx8fDE3NzEyNTA0MDR8MA&ixlib=rb-4.1.0&q=80&w=1080',
      description: 'Complete branding and visual identity for tech startup',
    },
    {
      id: 4,
      title: 'Viral Reels Campaign',
      category: 'Video',
      image: 'https://images.unsplash.com/photo-1764664035139-fe5fc6799499?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx2aWRlbyUyMHByb2R1Y3Rpb24lMjBjYW1lcmElMjBzZXR1cHxlbnwxfHx8fDE3NzEyNTA0MDV8MA&ixlib=rb-4.1.0&q=80&w=1080',
      description: 'Series of viral reels generating 10M+ views',
    },
    {
      id: 5,
      title: 'Lead Generation Campaign',
      category: 'Ads',
      image: 'https://images.unsplash.com/photo-1620313926202-159eb90ec94a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkaWdpdGFsJTIwbWFya2V0aW5nJTIwc29jaWFsJTIwbWVkaWElMjB3b3Jrc3BhY2V8ZW58MXx8fHwxNzcxMjUwNDA0fDA&ixlib=rb-4.1.0&q=80&w=1080',
      description: 'B2B lead generation campaign with 45% conversion rate',
    },
    {
      id: 6,
      title: 'Social Media Graphics Suite',
      category: 'Social Media',
      image: 'https://images.unsplash.com/photo-1770048792381-55d47c183faa?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxicmFuZGluZyUyMGRlc2lnbiUyMG1vY2t1cCUyMGxhcHRvcHxlbnwxfHx8fDE3NzEyNTA0MDR8MA&ixlib=rb-4.1.0&q=80&w=1080',
      description: 'Custom graphics library for consistent brand presence',
    },
  ];

  const filteredProjects =
    activeFilter === 'All'
      ? projects
      : projects.filter((project) => project.category === activeFilter);

  return (
    <section id="portfolio" className="py-20 sm:py-32 bg-white dark:bg-gray-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl sm:text-5xl font-bold mb-4 bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent">
            Portfolio
          </h2>
          <div className="w-20 h-1 bg-gradient-to-r from-purple-600 to-blue-600 mx-auto rounded-full mb-6" />
          <p className="text-gray-600 dark:text-gray-400 max-w-2xl mx-auto text-lg">
            A showcase of my best work and successful campaigns
          </p>
        </motion.div>

        {/* Filter Buttons */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="flex flex-wrap justify-center gap-3 mb-12"
        >
          {filters.map((filter) => (
            <motion.button
              key={filter}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => setActiveFilter(filter)}
              className={`px-6 py-2 rounded-full font-medium transition-all ${
                activeFilter === filter
                  ? 'bg-gradient-to-r from-purple-600 to-blue-600 text-white shadow-lg'
                  : 'bg-gray-100 dark:bg-gray-800 text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-700'
              }`}
            >
              {filter}
            </motion.button>
          ))}
        </motion.div>

        {/* Projects Grid */}
        <motion.div layout className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          <AnimatePresence mode="popLayout">
            {filteredProjects.map((project, index) => (
              <motion.div
                key={project.id}
                layout
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.8 }}
                transition={{ duration: 0.3 }}
                whileHover={{ y: -10 }}
                className="group relative"
              >
                <div className="relative bg-white dark:bg-gray-800 rounded-2xl overflow-hidden shadow-lg hover:shadow-2xl transition-all border border-gray-100 dark:border-gray-700">
                  {/* Image */}
                  <div className="relative h-64 overflow-hidden">
                    <ImageWithFallback
                      src={project.image}
                      alt={project.title}
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                    />
                    
                    {/* Overlay */}
                    <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
                      <motion.div
                        initial={{ y: 20, opacity: 0 }}
                        whileHover={{ y: 0, opacity: 1 }}
                        className="text-white text-center p-6"
                      >
                        <div className="w-12 h-12 bg-white/20 backdrop-blur-md rounded-full flex items-center justify-center mx-auto mb-3">
                          <ExternalLink size={20} />
                        </div>
                        <p className="text-sm font-medium">View Case Study</p>
                      </motion.div>
                    </div>
                  </div>

                  {/* Content */}
                  <div className="p-6">
                    <div className="inline-block px-3 py-1 bg-purple-100 dark:bg-purple-900/30 text-purple-600 dark:text-purple-400 text-xs font-medium rounded-full mb-3">
                      {project.category}
                    </div>
                    <h3 className="text-lg font-bold text-gray-900 dark:text-white mb-2">
                      {project.title}
                    </h3>
                    <p className="text-gray-600 dark:text-gray-400 text-sm">
                      {project.description}
                    </p>
                  </div>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        </motion.div>
      </div>
    </section>
  );
}
