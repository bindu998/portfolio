import { Toaster } from 'sonner';
import { Navigation } from './components/Navigation';
import { Hero } from './components/Hero';
import { About } from './components/About';
import { Services } from './components/Services';
import { Portfolio } from './components/Portfolio';
import { CaseStudies } from './components/CaseStudies';
import { Testimonials } from './components/Testimonials';
import { Contact } from './components/Contact';
import { Footer } from './components/Footer';
import { DarkModeToggle } from './components/DarkModeToggle';
import { ScrollToTop } from './components/ScrollToTop';

export default function App() {
  return (
    <div className="min-h-screen bg-white dark:bg-gray-900 transition-colors">
      <Toaster position="top-right" richColors />
      <Navigation />
      <main>
        <Hero />
        <About />
        <Services />
        <Portfolio />
        <CaseStudies />
        <Testimonials />
        <Contact />
      </main>
      <Footer />
      <DarkModeToggle />
      <ScrollToTop />
    </div>
  );
}