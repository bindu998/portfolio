
  # Personal Portfolio Website

  This is a code bundle for Personal Portfolio Website. The original project is available at https://www.figma.com/design/cVIsba2mjA9AqyVQ6lAFkr/Personal-Portfolio-Website.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  